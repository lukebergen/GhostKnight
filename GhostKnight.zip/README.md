# Ghost Knight
==============

This is the story of a man possessed by many ghosts.
